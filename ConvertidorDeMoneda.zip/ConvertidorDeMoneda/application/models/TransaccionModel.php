<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class TransaccionModel extends CI_Model
{
	
	function __construct()
	{
		parent:: __construct();
	}

	public function setConversion(string $Amount, string $ResultAmount, string $Rate)
	{
		return $this->db->query("INSERT INTO transaccion (Amount, ResultAmount, Rate) 
			values ({$Amount}, {$ResultAmount}, {$Rate})");
	}
}
?>