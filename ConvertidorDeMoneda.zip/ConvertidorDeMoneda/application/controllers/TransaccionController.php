<?php
	 function GetConversion()
	{
			$amount= ($_POST["Amount"]);
			$from = 'DOP';
			$to = 'USD';

			$endpoint = 'convert';
			$access_key = 'fd7cee0accb455f953d3c445f4b12c6a';

			// initialize CURL:
			$ch = curl_init('https://data.fixer.io/api/'.$endpoint.'?access_key='.$access_key.'&from='.$from.'&to='.$to.'&amount='.$amount.'');   
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

			// get the (still encoded) JSON data:
			$json = curl_exec($ch);
			curl_close($ch);

			// Decode JSON response:
			$conversionResult = json_decode($json, true);

			// access the conversion result
			return $conversionResult['result'];
	}

	 function GetRate()
	{
			$endpoint = 'latest';// Initialize CURL:
			$access_key = 'fd7cee0accb455f953d3c445f4b12c6a';
			$ch1 = curl_init('https://data.fixer.io/api/'.$endpoint.'?access_key='.$access_key.'');
			curl_setopt($ch1, CURLOPT_RETURNTRANSFER, true);

			// Store the data:
			$json = curl_exec($ch1);
			curl_close($ch1);

			// Decode JSON response:
			$exchangeRates = json_decode($json, true);

			// Access the exchange rate values, e.g. USD:
			 return ($exchangeRates['rates']['USD']);
			  
	}

defined('BASEPATH') OR exit('No direct script access allowed');
 class TransaccionController extends CI_Controller
{
	
	function __construct()
	{
		parent:: __construct();
		$this->load->database();
		$this->load->model('TransaccionModel');
	}
	public function index()
	{
		$this->load->view("Transaccion");
	}

	public function AddTransaccion()
	{	
		if($this->input->post()){
			$Amount = $this->db->escape($_POST["Amount"]);
			$ResultAmount = GetConversion();
			$Rate = GetRate();
			if($this->TransaccionModel->setConversion($Amount, $ResultAmount, $Rate));
			{
				
				$this->load->view("Transaccion");

				$result = "El equivalente de " . $Amount . " (DOP), es ". $ResultAmount . " (USD) ";
				//echo $result;
				echo '<span style="color:red; font-size:18px; position:fixed; bottom: 220px; right: 400px;
				 width: 500px;">'.$result.'</span>';
			}
		}
	}
}
?>